local config = {
    whitelist = "",
    dry_run = true,
}

local WHITELIST_FILE = PLUGIN_DIR .. "/whitelist.txt"

local function load_config()
    local function bool(v, d)
        if v == nil or v == "" then return d end
        return v == "true"
    end
    config.whitelist = get_config("whitelist") or ""
    config.dry_run = bool(get_config("dry_run"), true)
end

local function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function load_whitelist_file()
    local wl = {}
    local ok, data = pcall(read_file, WHITELIST_FILE)
    if not ok or not data or data == "" then
        return wl
    end
    for line in string.gmatch(data, "[^\r\n]+") do
        local pkg = trim(line)
        if pkg ~= "" and string.sub(pkg, 1, 1) ~= "#" then
            wl[pkg] = true
        end
    end
    return wl
end

local function get_whitelist()
    local wl = {}
    for entry in string.gmatch(config.whitelist .. ",", "([^,]+)") do
        local pkg = trim(entry)
        if pkg ~= "" then wl[pkg] = true end
    end
    for pkg, _ in pairs(load_whitelist_file()) do
        wl[pkg] = true
    end
    return wl
end

local function get_user_packages()
    local pkgs = {}
    local r = exec("sh", "-c", "pm list packages -3")
    if not r.ok then return pkgs end
    for line in string.gmatch(r.stdout, "package:([^\n]+)") do
        table.insert(pkgs, line)
    end
    return pkgs
end

local function is_running(pkg)
    local r = exec("sh", "-c", "pidof " .. pkg .. " 2>/dev/null")
    if r.ok and r.stdout and r.stdout ~= "" then
        return true
    end
    local r2 = exec("sh", "-c", "ps -A -o PID,NAME | grep -w " .. pkg .. " 2>/dev/null")
    if r2.ok and r2.stdout and r2.stdout ~= "" then
        return true
    end
    return false
end

local function kill_app(pkg)
    if config.dry_run then
        info("[DRY RUN] " .. pkg)
        return true
    end

    if not is_running(pkg) then
        return true
    end

    exec("sh", "-c", "am force-stop --user 0 " .. pkg .. " 2>/dev/null")

    os.execute("sleep 1")

    if not is_running(pkg) then
        info("killed " .. pkg)
        return true
    end

    local r = exec("sh", "-c", "pidof " .. pkg .. " 2>/dev/null")
    if r.ok and r.stdout and r.stdout ~= "" then
        local pids = {}
        for pid in string.gmatch(r.stdout, "%d+") do
            table.insert(pids, pid)
        end
        if #pids > 0 then
            exec("sh", "-c", "for pid in " .. table.concat(pids, " ") .. "; do kill -9 $pid 2>/dev/null; done")
            os.execute("sleep 1")
        end
    end

    exec("sh", "-c", "killall -9 " .. pkg .. " 2>/dev/null || true")
    os.execute("sleep 1")

    if not is_running(pkg) then
        info("killed " .. pkg)
        return true
    end

    warn(pkg .. " survived")
    return false
end

local function run_kill()
    load_config()
    local whitelist = get_whitelist()
    local pkgs = get_user_packages()
    local protected_count = 0
    local killed_count = 0
    local skipped_count = 0
    local failed_count = 0

    for _, pkg in ipairs(pkgs) do
        if whitelist[pkg] then
            protected_count = protected_count + 1
            info("protected " .. pkg)
            goto next_pkg
        end

        if not is_running(pkg) then
            skipped_count = skipped_count + 1
            goto next_pkg
        end

        if kill_app(pkg) then
            killed_count = killed_count + 1
        else
            failed_count = failed_count + 1
        end

        ::next_pkg::
    end

    info("done: " .. #pkgs .. " user apps, " .. protected_count .. " protected, " .. skipped_count .. " already dead, " .. killed_count .. " killed, " .. failed_count .. " failed")
end

load_config()

return {
    post_fs_data = function()
        info("quiet-kill loaded (dry_run: " .. tostring(config.dry_run) .. ")")
    end,

    service = function()
        info("quiet-kill ready")
    end,

    boot_completed = function()
        info("quiet-kill idle — tap Kill Now to run")
    end,

    action = function()
        info("kill triggered")
        run_kill()
    end,

    kill_now = function()
        run_kill()
    end,
}
