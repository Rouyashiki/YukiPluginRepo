local config = {
    older_than_days = 7,
}

local RAN_FILE = PLUGIN_DIR .. "/boot_ran"

local function trim(s)
    if not s then return "" end
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function load_config()
    local function num(v, d)
        local n = tonumber(v)
        return n ~= nil and n or d
    end
    config.older_than_days = num(get_config("older_than_days"), 7)
end

local function already_ran_today()
    local ok, data = pcall(read_file, RAN_FILE)
    if ok and data then
        return trim(data) == os.date("%Y-%m-%d")
    end
    return false
end

local function mark_ran()
    pcall(write_file, RAN_FILE, os.date("%Y-%m-%d"))
end

local function clean()
    load_config()
    info("Cleaning...")

    local paths = {
        "/data/local/tmp/",
        "/data/system/dropbox/",
        "/data/vendor/log/",
    }

    local total = 0

    for _, path in ipairs(paths) do
        local r = exec("sh", "-c", "find " .. path .. " -type f -mtime +" .. config.older_than_days .. " 2>/dev/null | wc -l")
        if r.ok and r.stdout then
            local count = tonumber(trim(r.stdout)) or 0
            if count > 0 then
                exec("sh", "-c", "find " .. path .. " -type f -mtime +" .. config.older_than_days .. " -delete 2>/dev/null")
                info("Deleted " .. count .. " from " .. path)
                total = total + count
            end
        end
    end

    local r2 = exec("sh", "-c", "find /data/adb/modules/*/ -name '*.log' -mtime +" .. config.older_than_days .. " 2>/dev/null | wc -l")
    if r2.ok and r2.stdout then
        local count = tonumber(trim(r2.stdout)) or 0
        if count > 0 then
            exec("sh", "-c", "find /data/adb/modules/*/ -name '*.log' -mtime +" .. config.older_than_days .. " -delete 2>/dev/null")
            info("Deleted " .. count .. " module logs")
            total = total + count
        end
    end

    info("Done: " .. total .. " files removed")
end

load_config()

return {
    post_fs_data = function()
        info("boot-cleaner loaded")
    end,

    service = function()
        info("boot-cleaner service started")
    end,

    boot_completed = function()
        if already_ran_today() then
            info("boot-cleaner already ran today")
            return
        end
        info("boot-cleaner running")
        clean()
        mark_ran()
    end,

    action = function()
        info("manual clean")
        clean()
    end,

    clean_now = function()
        clean()
    end,
}
