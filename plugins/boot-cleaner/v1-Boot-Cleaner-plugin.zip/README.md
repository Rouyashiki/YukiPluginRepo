# Boot Cleaner

Deletes old temp files and logs every time your phone boots.

## What it cleans

/data/local/tmp/
/data/system/dropbox/
/data/vendor/log/
Module log files in /data/adb/modules/

## Config

Delete files older than "x days" before a file gets deleted. Default is 7.

## Note

It only runs once per day at boot. If you reboot multiple times in one day, it skips the extra runs.
Tap Clean Now in the manager to run it manually anytime.
