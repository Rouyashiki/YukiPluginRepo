local config = {
    enabled = true,
    mode = "auto",
    threshold = 65,
    restore_threshold = 55,
    check_interval = 30,
}

local throttled = false
local original_governors = {}

local function trim(s)
    if not s then return "" end
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function load_config()
    local function num(v, d)
        local n = tonumber(v)
        return n ~= nil and n or d
    end
    local function bool(v, d)
        if v == nil or v == "" then return d end
        return v == "true"
    end
    config.enabled = bool(get_config("enabled"), true)
    config.mode = get_config("mode") or "auto"
    config.threshold = num(get_config("threshold"), 65)
    config.restore_threshold = num(get_config("restore_threshold"), 55)
    config.check_interval = num(get_config("check_interval"), 30)
end

local function get_cpu_temp()
    local zones = {
        "/sys/class/thermal/thermal_zone0/temp",
        "/sys/class/thermal/thermal_zone1/temp",
        "/sys/class/thermal/thermal_zone2/temp",
        "/sys/class/thermal/thermal_zone3/temp",
        "/sys/class/thermal/thermal_zone4/temp",
        "/sys/class/thermal/thermal_zone5/temp",
        "/sys/class/thermal/thermal_zone6/temp",
        "/sys/class/thermal/thermal_zone7/temp",
    }
    for _, path in ipairs(zones) do
        local r = exec("sh", "-c", "cat " .. path .. " 2>/dev/null")
        if r.ok and r.stdout then
            local t = tonumber(trim(r.stdout))
            if t then
                if t > 1000 then t = t / 1000 end
                if t > 0 and t < 150 then
                    return t, path
                end
            end
        end
    end
    return nil, nil
end

local function get_governor_paths()
    local paths = {}
    local r = exec("sh", "-c", "ls /sys/devices/system/cpu/cpu[0-9]/cpufreq/scaling_governor 2>/dev/null")
    if not r.ok or not r.stdout then return paths end
    for path in string.gmatch(r.stdout, "[^\r\n]+") do
        local core = string.match(path, "cpu(%d+)")
        if core then
            table.insert(paths, { core = tonumber(core), path = path })
        end
    end
    return paths
end

local function read_file_path(path)
    local r = exec("sh", "-c", "cat " .. path .. " 2>/dev/null")
    if r.ok and r.stdout then
        return trim(r.stdout)
    end
    return nil
end

local function write_file_path(path, value)
    exec("sh", "-c", "echo " .. value .. " > " .. path .. " 2>/dev/null")
    os.execute("sleep 0.3")
    local actual = read_file_path(path)
    return actual == value
end

local function get_core_freq(core)
    local min = read_file_path("/sys/devices/system/cpu/cpu" .. core .. "/cpufreq/cpuinfo_min_freq") or "?"
    local max = read_file_path("/sys/devices/system/cpu/cpu" .. core .. "/cpufreq/cpuinfo_max_freq") or "?"
    local cur = read_file_path("/sys/devices/system/cpu/cpu" .. core .. "/cpufreq/scaling_cur_freq") or "?"
    return min, max, cur
end

local function log_all_cores()
    local cores = get_governor_paths()
    info("--- CPU Status ---")
    for _, c in ipairs(cores) do
        local gov = read_file_path(c.path) or "?"
        local min, max, cur = get_core_freq(c.core)
        info("Core " .. c.core .. ": gov=" .. gov .. " cur=" .. cur .. " min=" .. min .. " max=" .. max)
    end
    info("------------------")
end

local function save_original_governors()
    original_governors = {}
    local cores = get_governor_paths()
    for _, c in ipairs(cores) do
        local gov = read_file_path(c.path)
        if gov then
            original_governors[c.core] = gov
        end
    end
end

local function apply_governor(target_gov, all_cores)
    local cores = get_governor_paths()
    local success = 0
    local failed = 0
    local skipped = 0

    for _, c in ipairs(cores) do
        if not all_cores and c.core == 0 then
            skipped = skipped + 1
            goto next_core
        end

        local current = read_file_path(c.path)
        if not current then
            failed = failed + 1
            goto next_core
        end

        if current == target_gov then
            success = success + 1
            goto next_core
        end

        if write_file_path(c.path, target_gov) then
            info("Core " .. c.core .. ": " .. current .. " -> " .. target_gov)
            success = success + 1
        else
            warn("Core " .. c.core .. ": failed to set " .. target_gov)
            failed = failed + 1
        end

        ::next_core::
    end

    return success, failed, skipped
end

local function throttle()
    if throttled then
        info("Already throttled")
        return
    end

    info("=== THROTTLING ===")
    save_original_governors()

    local success, failed, skipped = apply_governor("powersave", false)

    if success > 0 then
        throttled = true
        info("Throttled " .. success .. " cores to powersave")
        if skipped > 0 then
            info("Skipped " .. skipped .. " little cores")
        end
        if failed > 0 then
            warn(failed .. " cores failed")
        end
    else
        warn("Throttle failed on all cores")
    end

    log_all_cores()
end

local function restore()
    if not throttled then
        info("Not throttled, nothing to restore")
        return
    end

    info("=== RESTORING ===")
    local success = 0
    local failed = 0

    for core, gov in pairs(original_governors) do
        local path = "/sys/devices/system/cpu/cpu" .. core .. "/cpufreq/scaling_governor"
        local current = read_file_path(path)
        if current and current ~= gov then
            if write_file_path(path, gov) then
                info("Core " .. core .. ": " .. current .. " -> " .. gov)
                success = success + 1
            else
                warn("Core " .. core .. ": restore failed")
                failed = failed + 1
            end
        else
            success = success + 1
        end
    end

    if success > 0 then
        throttled = false
        original_governors = {}
        info("Restored " .. success .. " cores")
        if failed > 0 then
            warn(failed .. " cores failed restore")
        end
    else
        warn("Restore failed on all cores")
    end

    log_all_cores()
end

local function force_performance()
    info("=== PERFORMANCE MODE ===")
    if throttled then
        restore()
    end
    local success, failed, skipped = apply_governor("performance", true)
    info("Performance applied: " .. success .. " OK, " .. failed .. " failed")
    log_all_cores()
end

local function force_powersave()
    info("=== POWERSAVE MODE ===")
    if not throttled then
        save_original_governors()
    end
    local success, failed, skipped = apply_governor("powersave", true)
    throttled = true
    info("Powersave applied: " .. success .. " OK, " .. failed .. " failed")
    log_all_cores()
end

local function run_auto()
    local temp, zone = get_cpu_temp()
    if not temp then
        warn("Cannot read temperature from any thermal zone")
        return
    end

    info("Temp: " .. temp .. "C (from " .. zone .. ")")

    if temp >= config.threshold then
        info("HOT: " .. temp .. "C >= threshold " .. config.threshold .. "C")
        if not throttled then
            throttle()
        else
            info("Already throttled")
        end
    elseif temp <= config.restore_threshold then
        info("COOL: " .. temp .. "C <= restore " .. config.restore_threshold .. "C")
        if throttled then
            restore()
        else
            info("Already normal")
        end
    else
        info("NORMAL: " .. temp .. "C (between " .. config.restore_threshold .. "-" .. config.threshold .. "C)")
    end
end

local function run_apply()
    load_config()

    if not config.enabled then
        info("Thermal Guard is disabled")
        if throttled then
            info("Restoring because plugin was disabled")
            restore()
        end
        return
    end

    info("Applying mode: " .. config.mode)

    if config.mode == "performance" then
        force_performance()
        return
    end

    if config.mode == "powersave" then
        force_powersave()
        return
    end

    run_auto()
end

load_config()

return {
    post_fs_data = function()
        info("thermal-guard loaded")
        info("Mode: " .. config.mode .. " | Threshold: " .. config.threshold .. "C | Restore: " .. config.restore_threshold .. "C")
    end,

    service = function()
        info("thermal-guard service started")
    end,

    boot_completed = function()
        info("thermal-guard ready")
        run_apply()
    end,

    main = function()
        while true do
            run_apply()
            os.execute("sleep " .. config.check_interval)
        end
    end,

    action = function()
        info("manual apply triggered")
        run_apply()
    end,

    apply_now = function()
        run_apply()
    end,
}
