# Thermal Guard

Monitors your CPU temperature and switches the governor to keep your phone cool or fast.

## Modes

Auto: watches temperature and switches to powersave when hot, restores when cool.
Performance: forces all cores to performance governor for gaming.
Powersave: forces all cores to powersave governor to save battery.

## Config

Mode: pick auto, performance, or powersave.
Threshold: temperature in Celsius where throttling starts.
Restore: temperature in Celsius where it stops throttling.
Check interval: how often to check temp in seconds.
Enable: master on/off switch.

## How it works

In auto mode, if temp goes above threshold, big cores switch to powersave.
When temp drops below restore, everything goes back to normal.
The 10 degree gap between threshold and restore stops rapid on/off flipping.

