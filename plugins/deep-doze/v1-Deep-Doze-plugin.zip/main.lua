local config = {
    sleep_start = 23,
    sleep_end = 7,
    check_interval = 15,
    skip_charging = true,
}

local dozed = false

local function load_config()
    local function num(v, d)
        local n = tonumber(v)
        return n ~= nil and n or d
    end
    local function bool(v, d)
        if v == nil or v == "" then return d end
        return v == "true"
    end
    config.sleep_start = num(get_config("sleep_start"), 23)
    config.sleep_end = num(get_config("sleep_end"), 7)
    config.check_interval = num(get_config("check_interval"), 15)
    config.skip_charging = bool(get_config("skip_charging"), true)
end

local function is_sleep_time()
    local now = os.date("*t").hour
    local s = config.sleep_start
    local e = config.sleep_end
    if s < e then
        return now >= s and now < e
    else
        return now >= s or now < e
    end
end

local function is_screen_off()
    local r = exec("sh", "-c", "dumpsys power 2>/dev/null | grep -o 'mWakefulness=[^,]*' | head -n 1")
    if r.ok and r.stdout then
        return string.match(r.stdout, "Asleep") ~= nil or string.match(r.stdout, "Dozing") ~= nil
    end
    local r2 = exec("sh", "-c", "dumpsys display 2>/dev/null | grep -o 'mScreenState=[^,]*' | head -n 1")
    if r2.ok and r2.stdout then
        return string.match(r2.stdout, "OFF") ~= nil
    end
    return false
end

local function is_charging()
    local r = exec("sh", "-c", "cat /sys/class/power_supply/battery/status 2>/dev/null")
    if r.ok and r.stdout then
        return string.match(r.stdout, "Charging") ~= nil or string.match(r.stdout, "Full") ~= nil
    end
    return false
end

local function enter_doze()
    if dozed then return end
    local r = exec("sh", "-c", "dumpsys deviceidle force-idle 2>/dev/null")
    if r.ok then
        dozed = true
        info("Deep doze: ON")
    else
        warn("Deep doze failed")
    end
end

local function exit_doze()
    if not dozed then return end
    exec("sh", "-c", "dumpsys deviceidle unforce 2>/dev/null")
    dozed = false
    info("Deep doze: OFF")
end

local function run_check()
    load_config()

    local now = os.date("*t").hour
    info("Time: " .. now .. ":00 | Sleep window: " .. config.sleep_start .. ":00-" .. config.sleep_end .. ":00")

    if not is_sleep_time() then
        info("Reason: Not sleep time")
        exit_doze()
        return
    end

    if config.skip_charging and is_charging() then
        info("Reason: Charging")
        exit_doze()
        return
    end

    if not is_screen_off() then
        info("Reason: Screen is on")
        exit_doze()
        return
    end

    info("Reason: Sleep time, screen off, not charging")
    enter_doze()
end

load_config()

return {
    post_fs_data = function()
        info("deep-doze loaded | Sleep: " .. config.sleep_start .. ":00 to " .. config.sleep_end .. ":00")
    end,

    service = function()
        info("deep-doze service started")
    end,

    boot_completed = function()
        info("deep-doze ready")
    end,

    main = function()
        while true do
            run_check()
            os.execute("sleep " .. (config.check_interval * 60))
        end
    end,

    action = function()
        info("manual doze triggered")
        enter_doze()
    end,

    doze_now = function()
        enter_doze()
    end,
}
