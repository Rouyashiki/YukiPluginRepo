local config = {
    default_dns = "auto",
    mobile_dns = "dns.google",
    wifi_dns = "dns.adguard-dns.com",
    ssid_map = "",
    check_interval = 5,
}

local function load_config()
    local function num(v, d)
        local n = tonumber(v)
        return n ~= nil and n or d
    end
    config.default_dns = get_config("default_dns") or config.default_dns
    config.mobile_dns = get_config("mobile_dns") or config.mobile_dns
    config.wifi_dns = get_config("wifi_dns") or config.wifi_dns
    config.ssid_map = get_config("ssid_map") or config.ssid_map
    config.check_interval = num(get_config("check_interval"), 5)
end

local function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function parse_ssid_map(str)
    local map = {}
    if not str or str == "" then return map end
    for entry in string.gmatch(str .. ",", "([^,]+)") do
        local ssid, dns = string.match(trim(entry), "^([^=]+)=(.+)$")
        if ssid and dns then
            map[trim(ssid)] = trim(dns)
        end
    end
    return map
end

local function get_current_dns()
    local r1 = exec("sh", "-c", "settings get global private_dns_mode 2>/dev/null")
    local r2 = exec("sh", "-c", "settings get global private_dns_specifier 2>/dev/null")
    local mode = trim(r1.stdout or "unknown")
    local spec = trim(r2.stdout or "none")
    if mode == "null" or mode == "" then mode = "unknown" end
    if spec == "null" or spec == "" then spec = "none" end
    return mode, spec
end

local function get_network()
    local r = exec("sh", "-c", "dumpsys wifi 2>/dev/null | grep -o 'SSID: \"[^\"]*\"' | head -n 1")
    if r.ok and r.stdout and r.stdout ~= "" then
        local ssid = string.match(r.stdout, 'SSID: "([^"]+)"')
        if ssid and ssid ~= "<unknown ssid>" and ssid ~= "0x" and ssid ~= "0x0" then
            return "wifi", ssid
        end
    end
    local r2 = exec("sh", "-c", "dumpsys connectivity 2>/dev/null | grep -c 'MOBILE.*CONNECTED'")
    if r2.ok and r2.stdout and tonumber(r2.stdout) > 0 then
        return "mobile", nil
    end
    return "unknown", nil
end

local function apply_dns(dns)
    if dns == "auto" or dns == "automatic" or dns == "" then
        exec("sh", "-c", "settings put global private_dns_mode opportunistic 2>/dev/null")
        exec("sh", "-c", "settings put global private_dns_specifier '' 2>/dev/null")
        return "automatic"
    end
    exec("sh", "-c", "settings put global private_dns_mode hostname 2>/dev/null")
    exec("sh", "-c", "settings put global private_dns_specifier '" .. dns .. "' 2>/dev/null")
    return dns
end

local function run_flip()
    load_config()
    local old_mode, old_spec = get_current_dns()
    local net_type, ssid = get_network()
    local ssid_map = parse_ssid_map(config.ssid_map)
    local dns = config.default_dns

    if net_type == "wifi" and ssid and ssid_map[ssid] then
        dns = ssid_map[ssid]
        info("Network: WiFi '" .. ssid .. "'")
    elseif net_type == "wifi" then
        dns = config.wifi_dns
        info("Network: WiFi")
    elseif net_type == "mobile" then
        dns = config.mobile_dns
        info("Network: Mobile data")
    else
        info("Network: Unknown")
    end

    local applied = apply_dns(dns)
    info("DNS: " .. old_mode .. "/" .. old_spec .. " -> " .. applied)
end

load_config()

return {
    post_fs_data = function()
        info("dns-flip loaded")
    end,

    service = function()
        info("dns-flip service started")
    end,

    boot_completed = function()
        info("dns-flip ready")
    end,

    main = function()
        while true do
            run_flip()
            os.execute("sleep " .. (config.check_interval * 60))
        end
    end,

    action = function()
        info("manual flip triggered")
        run_flip()
    end,

    flip_now = function()
        run_flip()
    end,
}
