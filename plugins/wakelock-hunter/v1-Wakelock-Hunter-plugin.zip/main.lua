local function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function strip_ansi(s)
    if not s then return "" end
    return string.gsub(s, "\27%[[0-9;]*[a-zA-Z]", "")
end

local function get_battery_drain()
    local r = exec("sh", "-c", "cat /sys/class/power_supply/battery/current_now 2>/dev/null")
    if r.ok and r.stdout then
        local ma = tonumber(r.stdout)
        if ma then
            return math.floor(math.abs(ma) / 1000)
        end
    end
    return nil
end

local function get_alarm_apps()
    local apps = {}
    local r = exec("sh", "-c", "dumpsys alarm 2>/dev/null")
    if not r.ok or not r.stdout then return apps end

    local current_pkg = nil
    for line in string.gmatch(r.stdout, "[^\r\n]+") do
        local pkg = string.match(line, "Alarm{[^}]+}%s+([%w%.%-_]+)$")
        if pkg then
            current_pkg = pkg
        end
        if current_pkg and string.match(line, "type=") then
            apps[current_pkg] = (apps[current_pkg] or 0) + 1
            current_pkg = nil
        end
    end
    return apps
end

local function get_wakelock_apps()
    local apps = {}
    local r = exec("sh", "-c", "dumpsys power 2>/dev/null")
    if not r.ok or not r.stdout then return apps end

    local in_wakelocks = false
    for line in string.gmatch(r.stdout, "[^\r\n]+") do
        if string.match(line, "Wake Locks:") then
            in_wakelocks = true
        elseif in_wakelocks and string.match(line, "^%s*$") then
            in_wakelocks = false
        elseif in_wakelocks then
            local lock_name = string.match(line, '"([^"]+)"')
            if lock_name then
                apps[lock_name] = (apps[lock_name] or 0) + 1
            end
        end
    end
    return apps
end

local function get_cpu_hogs()
    local hogs = {}
    local r = exec("sh", "-c", "ps -A -o NAME,PID,CPU 2>/dev/null | tail -n +2 | sort -k3 -nr | head -n 8")
    if not r.ok or not r.stdout then return hogs end
    for line in string.gmatch(strip_ansi(r.stdout), "[^\r\n]+") do
        local name, pid, cpu = string.match(trim(line), "^([%S]+)%s+(%d+)%s+([%d%.]+)")
        if name and cpu and tonumber(cpu) > 0 then
            table.insert(hogs, { name = name, cpu = tonumber(cpu) })
        end
    end
    return hogs
end

local function run_hunt()
    info("=== Battery Check ===")

    local drain = get_battery_drain()
    if drain then
        if drain > 500 then
            info("Drain: " .. drain .. " mA (heavy)")
        elseif drain > 200 then
            info("Drain: " .. drain .. " mA (moderate)")
        else
            info("Drain: " .. drain .. " mA (light)")
        end
    else
        info("Drain: unknown")
    end

    local alarms = get_alarm_apps()
    local alarm_count = 0
    for _, count in pairs(alarms) do
        alarm_count = alarm_count + count
    end

    if alarm_count > 0 then
        info("--- Apps with alarms (" .. alarm_count .. " total) ---")
        local sorted = {}
        for pkg, count in pairs(alarms) do
            table.insert(sorted, { pkg = pkg, count = count })
        end
        table.sort(sorted, function(a, b) return a.count > b.count end)
        for i, item in ipairs(sorted) do
            if i > 5 then break end
            info(i .. ". " .. item.pkg .. " — " .. item.count .. " alarm" .. (item.count > 1 and "s" or ""))
        end
    else
        info("No alarms found")
    end

    local locks = get_wakelock_apps()
    local lock_count = 0
    for _, count in pairs(locks) do
        lock_count = lock_count + count
    end

    if lock_count > 0 then
        info("--- Active wakelocks (" .. lock_count .. " total) ---")
        local sorted = {}
        for name, count in pairs(locks) do
            table.insert(sorted, { name = name, count = count })
        end
        table.sort(sorted, function(a, b) return a.count > b.count end)
        for i, item in ipairs(sorted) do
            if i > 5 then break end
            info(i .. ". " .. item.name .. " — " .. item.count .. " lock" .. (item.count > 1 and "s" or ""))
        end
    else
        info("No wakelocks found")
    end

    local cpu = get_cpu_hogs()
    if #cpu > 0 then
        info("--- CPU usage right now ---")
        for i, item in ipairs(cpu) do
            info(i .. ". " .. item.name .. " — " .. item.cpu .. "%")
        end
    else
        info("No CPU hogs")
    end

    info("Tip: Force-stop the top apps to save battery.")
    info("=== Done ===")
end

return {
    post_fs_data = function()
        info("wakelock-hunter loaded")
    end,

    service = function()
        info("wakelock-hunter ready")
    end,

    boot_completed = function()
        info("wakelock-hunter idle")
    end,

    action = function()
        info("hunt triggered")
        run_hunt()
    end,

    hunt_now = function()
        run_hunt()
    end,
}
