local config = {
    mode = "balanced",
    check_interval = 30,
}

local function trim(s)
    if not s then return "" end
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

local function load_config()
    config.mode = get_config("mode") or "balanced"
    local function num(v, d)
        local n = tonumber(v)
        return n ~= nil and n or d
    end
    config.check_interval = num(get_config("check_interval"), 30)
end

local function get_current_constants()
    local r = exec("sh", "-c", "settings get global device_idle_constants 2>/dev/null")
    if r.ok and r.stdout then
        local val = trim(r.stdout)
        if val ~= "" and val ~= "null" then
            return val
        end
    end
    return "default"
end

local function get_mode_constants()
    if config.mode == "aggressive" then
        return "light_after_inactive_to=5000,inactive_to=30000,sensing_to=0,locating_to=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=30000,max_idle_pending_to=60000,quick_doze_delay_to=30000,idle_to=1800000,max_idle_to=10800000,min_time_to_alarm=3600000"
    elseif config.mode == "relaxed" then
        return "light_after_inactive_to=600000,inactive_to=3600000,sensing_to=60000,locating_to=60000,motion_inactive_to=60000,idle_after_inactive_to=60000,idle_pending_to=600000,max_idle_pending_to=1200000,quick_doze_delay_to=300000,idle_to=7200000,max_idle_to=21600000,min_time_to_alarm=3600000"
    else
        return "light_after_inactive_to=300000,inactive_to=1800000,sensing_to=0,locating_to=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=300000,max_idle_pending_to=600000,quick_doze_delay_to=60000,idle_to=3600000,max_idle_to=21600000,min_time_to_alarm=3600000"
    end
end

local function apply_constants(constants)
    local r = exec("sh", "-c", "settings put global device_idle_constants '" .. constants .. "' 2>&1")
    if r.ok then
        return true
    else
        return false
    end
end

local function run_apply()
    load_config()
    local current = get_current_constants()
    local target = get_mode_constants()

    if current == target then
        return
    end

    local ok = apply_constants(target)
    if ok then
        info("Doze: " .. config.mode)
    else
        warn("Doze apply failed")
    end
end

local function reset_to_default()
    exec("sh", "-c", "settings delete global device_idle_constants 2>/dev/null")
    info("Doze reset to default")
end

load_config()

return {
    post_fs_data = function()
        info("doze-delay loaded (" .. config.mode .. ")")
    end,

    service = function()
        info("doze-delay service started")
    end,

    boot_completed = function()
        info("doze-delay ready")
        run_apply()
    end,

    main = function()
        while true do
            run_apply()
            os.execute("sleep " .. (config.check_interval * 60))
        end
    end,

    action = function()
        info("manual apply")
        run_apply()
    end,

    apply_now = function()
        run_apply()
    end,
}
