# Doze Delay

Controls how fast your phone enters doze mode. Faster doze saves battery. Slower doze keeps apps alive.

## Modes

Aggressive: enters doze in about 30 seconds. Best battery, delayed notifications.
Balanced: enters doze in about 30 minutes. Default Android behavior.
Relaxed: enters doze in about 1 hour. Apps stay alive longer, worse battery.

## Config

Mode: pick aggressive, balanced, or relaxed.
Re-apply interval: minutes between checks. Default is 30.

## How it works

It writes device idle constants to Android settings.
Some apps or system updates might reset them, so it re-applies automatically.
Tap Apply Now to force it immediately.
Changes need reboot to fully take effect.
